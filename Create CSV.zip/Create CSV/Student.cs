﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Create_CSV
{
    internal class Student
    {
        public  string StudentID { get; set; }
        public string StudentName { get; set; }
        public string StudentEmail { get; set;}

        public string   Phone { get; set; }
    
    }
}
